<?php

return [
    'language_exists' => 'Die Sprache { :language } ist bereits vorhanden',
    'key_exists' => 'Der Übersetzungsschlüssel { :key } ist bereits vorhanden',
];
