<?php

return [
    'language_exists' => 'اللغة { :language } موجودة بالفعل',
    'key_exists' => 'المتغير { :key } موجود بالفعل',
];
