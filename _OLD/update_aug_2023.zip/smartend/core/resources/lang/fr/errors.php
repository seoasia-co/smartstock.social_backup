<?php

return [
    'key_exists' => 'La clé de traduction { :key } existe déjà',
    'language_exists' => 'La langue { :language } existe déjà',
];
