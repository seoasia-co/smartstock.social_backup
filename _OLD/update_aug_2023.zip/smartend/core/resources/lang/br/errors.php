<?php

return [
    'language_exists' => 'A linguagem { :language } já existe',
    'key_exists' => 'Esta tradução { :key } já existe',
];
